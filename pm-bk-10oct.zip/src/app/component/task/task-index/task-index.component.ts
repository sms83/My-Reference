import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-index',
  templateUrl: './task-index.component.html',
  styleUrls: ['./task-index.component.css']
})
export class TaskIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
