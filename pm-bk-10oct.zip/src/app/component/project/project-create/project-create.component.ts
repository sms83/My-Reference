import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProjectService } from '../project.service';
import { FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-project-create',
  templateUrl: './project-create.component.html',
  styleUrls: ['./project-create.component.css']
})
export class ProjectCreateComponent implements OnInit {

  constructor(private router: Router, private api: ProjectService, private formBuilder: FormBuilder) { }


  uri = 'http://localhost:4000/pc';

  public searchText : string;
  user = {}
  projectlist : any;
  getCheckID = "";
  geteditrecord : any = {};
  url : any ;
  errorMessage : string;
  sortval : any ;

  projectForm: FormGroup;
  project_title: String;
  start_date :  Date;
  end_date:  Date;
  priority : Number;
  manager: String;

  ngOnInit() {

    this.fetchAll();

    this.projectForm = this.formBuilder.group({
      'project_title' : [null, Validators.required],
      'start_date' : [''],
      'end_date' : [''],
      'priority' : [null, Validators.required],
      'manager' : [null, Validators.required]
    });
  }

  fetchAll()
  {
    this.api.getProjects()
    .subscribe(res => {
      console.log(res);
      this.projectlist = res;
    }, err => {
      console.log(err);
    });

  }

  findbyID(id)
  {
    this.api.getProjectById(id)
    .subscribe(res => {
      console.log(res);
      this.geteditrecord = res;
    }, err => {
      console.log(err);
    });

  }
 
   // Add and update record
   onFormSubmit(form:NgForm) 
   {
     // Update Record
     if(!this.getCheckID) {
      this.api.postProject(form)
      .subscribe(res => {
           this.router.navigate(['/pc']);
        }, (err) => {
          console.log(err);
        });
     }
     else
     {
       // Add Record
       this.api.updateProject(this.getCheckID,form)
       .subscribe(res => {
            this.router.navigate(['/pc']);
         }, (err) => {
           console.log(err);
         });
     }
    }

   // Delete Record
   deleteBook(id) {
    this.api.deleteProject(id)
      .subscribe(res => {
          this.router.navigate(['/pc']);
        }, (err) => {
          console.log(err);
        }
      );
  }

}
