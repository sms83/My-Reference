export interface Project {
    id: Number;
    first_name: String;
    last_name: String;
    employee_id : Number;
}