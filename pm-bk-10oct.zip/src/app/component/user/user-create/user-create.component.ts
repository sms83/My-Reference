import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute,Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import { FilterPipe } from '../filters/filter.pipe';

@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.component.html',
  styleUrls: ['./user-create.component.css']
})
export class UserCreateComponent implements OnInit {

  uri = 'http://localhost:4000/uc';

  public searchText : string;
  user = {}
  userlist : any;
  getCheckID = "";
  geteditrecord : any = {};
  url : any ;
  errorMessage : string;
  sortval : any ;


  constructor( private location: Location, private route: ActivatedRoute, public http : HttpClient, public router: Router) { }

  pageRefresh() {
    location.reload();
 }

  ngOnInit() 
  {
    this.fetchall(this.sortval);
  }

  fetchall(val)
  {
    this.sortval = val;
   if(this.sortval) 
    { 
      this.http.get(`${this.uri}/sortUser/`+this.sortval).subscribe(data => {
        this.userlist = data;
        console.log('Done' + data);
      });
    }
    else{ 
       this.http.get(`${this.uri}/`).subscribe(data => {
        this.userlist = data;
        console.log('Done' + data);
      });
    }  
  }

  findbyID(id)
  {
    this.getCheckID = id;
      this.http.get(`${this.uri}/getUser/`+id).subscribe(res => {
      this.geteditrecord = res;
    });
  }

 
  // Delete Record
  deleteBook(id) 
  {
    this.http.delete(`${this.uri}/del`+id)
      .subscribe(res => {
        window.location.reload();
        }, (err) => {
          console.log(err);
          this.errorMessage= err.error_message;
        }
      );
  }

  // Add and update record
  saveUser() 
  {
    // Update Record
    if(!this.getCheckID) {
    this.url = `${this.uri}/save`;
    this.http.post(this.url, this.geteditrecord)
      .subscribe(res => {
        window.location.reload();
          
        }, (err) => {
          console.log(err);
          this.errorMessage= err.error_message;
        }
      );
    }
    else
    {
      // Add Record
    this.url = `${this.uri}/save/`+this.getCheckID;
    this.http.put(this.url, this.geteditrecord)
      .subscribe(res => {
        window.location.reload();
        }, (err) => {
          console.log(err);
          this.errorMessage= err.error_message;
        }
      );
    }
    
  }

  
}
