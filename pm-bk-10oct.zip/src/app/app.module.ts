import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { TaskCreateComponent } from './component/task/task-create/task-create.component';
import { TaskEditComponent } from './component/task/task-edit/task-edit.component';
import { TaskIndexComponent } from './component/task/task-index/task-index.component';
import { ProjectCreateComponent } from './component/project/project-create/project-create.component';
import { ProjectEditComponent } from './component/project/project-edit/project-edit.component';
import { ProjectIndexComponent } from './component/project/project-index/project-index.component';
import { UserIndexComponent } from './component/user/user-index/user-index.component';
import { UserCreateComponent } from './component/user/user-create/user-create.component';
import { UserEditComponent } from './component/user/user-edit/user-edit.component';
import { FilterPipe} from './component/user/filters/filter.pipe';

const routes: Routes = [
  {path:'tc', component :TaskCreateComponent},
  {path:'tv', component :TaskIndexComponent},
  {path:'pc', component :ProjectCreateComponent},
  {path:'uc', component :UserCreateComponent},
  {path:'uc/save/:id', component :UserEditComponent},
  { path: 'uc', redirectTo: '/', pathMatch: 'full'}
];


@NgModule({
  declarations: [
    AppComponent,
    TaskCreateComponent,
    TaskEditComponent,
    TaskIndexComponent,
    ProjectCreateComponent,
    ProjectEditComponent,
    ProjectIndexComponent,
    UserIndexComponent,
    UserCreateComponent,
    UserEditComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    FormsModule,
    HttpClientModule,
    FormsModule,   
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
