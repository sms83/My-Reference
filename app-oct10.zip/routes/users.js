var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var User = require('../models/user.model.js');

/*
router.get('/', function(req, res, next) {
  res.send('Express RESTful API --0');
});
 */
router.get('/a1', function(req, res, next) {
    res.send('Express RESTful API --A1');
  });

// Defined get data(index or listing) route
router.route('/').get(function (req, res) {
  User.find(function (err, taskLists){
  if(err){
    console.log(err);
    handleError(res, err.message, "Failed to get contacts.");
  }
  else {
    res.json(taskLists);
  }
});
});

/* SAVE User */
router.post('/save', function(req, res, next) {
  User.create(req.body, function (err, post) {
    if (err) { 
      handleError(res, err.message, "Failed to add contact.");
      return next(err);
     } else {
    res.json(post); }
  });
});


router.route('/getUser/:id').get(function (req, res) {
  let id = req.params.id;
  User.findById(id, function (err, userIdResult){
    
      if(err){
        console.log(err);
        handleError(res, err.message, "Failed to get contact.");
      }
      else {
        res.json(userIdResult);
      }
  });
});

router.route('/sortUser/:id').get(function (req, res) {
  let id = req.params.id;
  User.find().sort(id).find(function (err, userIdResult) {
    
      if(err){
        console.log(err);
        handleError(res, err.message, "Failed to get contact.");
      }
      else {
        res.json(userIdResult);
      }
  });
});

/* UPDATE User */
//router.post('/save/:id', function(req, res, next)
router.put('/save/:id', function(req, res, next) {
  User.findByIdAndUpdate(req.params.id, req.body, function (err, post) {
    if (err) { 
      handleError(res, err.message, "Failed to update contact.");
      return next(err);
     } else {
    res.json(post); }
  });
});

/* DELETE User */
router.delete('/del:id', function(req, res, next) {
  User.findByIdAndRemove(req.params.id, req.body, function (err, post) {
    if (err) { 
      handleError(res, err.message, "Failed to delete contact.");
      return next(err);
     } else {
    res.json(post); }
  });
});

module.exports = router;